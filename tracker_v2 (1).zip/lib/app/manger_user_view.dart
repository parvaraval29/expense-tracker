import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:tracker/app/models/Expense.dart';

import 'package:tracker/app/view_expense.dart';
import 'package:tracker/app/view_expense_manager.dart';
import 'package:tracker/services/app_user_info.dart';
import 'package:tracker/app/models/User.dart' as u;
import 'package:tracker/services/firestore_service.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class ManagerUserHomePage extends StatefulWidget {
  final u.User user;
  ManagerUserHomePage({this.user});
  @override
  _ManagerUserHomePageState createState() => _ManagerUserHomePageState();
}

class _ManagerUserHomePageState extends State<ManagerUserHomePage> {

  u.User _user;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _user = widget.user;
  }

  refreshUserData() {
    setState(() async {
      _user = await FirebaseService().getCurrentUser(widget.user.uid);
    });
  }

  _approveExpense(Expense _expense) async{
    await FirebaseService().approveExpense(_expense);
    await FirebaseService().addClaimed(_expense.userId, (_expense.amount-(2*_expense.amount)),_expense.amount);
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    u.User _user = widget.user;
    return Scaffold(
      appBar: AppBar(
        title: Text('Expenses'),
        actions: [
          Padding(
            padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.02),
            child: Center(
              child: Text('£ ${_user.unClaimed}'),
            ),
          ),
        ],
      ),
      backgroundColor: Colors.white,
      body: StreamBuilder(
          stream: FirebaseFirestore.instance.collection('expenses').where('userId', isEqualTo: _user.uid).where('status', isEqualTo: 'not-approved').snapshots(),
          builder: (context, snapshot) {
            return !snapshot.hasData
                ? CircularProgressIndicator()
                : ListView.builder(
              itemCount: snapshot.data.docs.length,
              itemBuilder: (context, index) {
                return expenseObject(snapshot.data.docs[index]);
              },
            );
          }),
    );
  }

  Widget expenseObject(doc) {
    Expense expense = Expense.fromMap(doc.data());
    return Slidable(
      key: const ValueKey(0),
      endActionPane: ActionPane(
        motion: ScrollMotion(),
        children: [
          SlidableAction(
            onPressed : (BuildContext)=>_approveExpense(expense),
            backgroundColor: Colors.green,
            foregroundColor: Colors.white,
            icon: Icons.check,
            label: 'Approve',
          ),
        ],
      ),
      child: InkWell(
        onTap: (){
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ViewExpenseManager(expense: expense,),
            ),
          ).then((value){
            refreshUserData();
          });
        },
        child: Column(
          children: [
            SizedBox(
              height: MediaQuery.of(context).size.height * 0.015,
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              padding: EdgeInsets.fromLTRB(MediaQuery.of(context).size.height * 0.01, MediaQuery.of(context).size.height * 0.008, MediaQuery.of(context).size.height * 0.01, MediaQuery.of(context).size.height * 0.008),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    DateFormat('dd/MM/yyyy').format(expense.date),
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: MediaQuery.of(context).size.width * 0.04, color: Colors.black),
                  ),
                  SizedBox(
                    height: 5,
                  ),
                  Text(
                    'Added on  : ${DateFormat('dd/MM/yyyy').format(expense.createdDateTime)}',
                    style: TextStyle(fontWeight: FontWeight.normal, fontSize: MediaQuery.of(context).size.width * 0.033, color: Colors.black54),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.width * 0.02,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        expense.label,
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: MediaQuery.of(context).size.width * 0.033,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        '£ ${expense.amount}',
                        style: TextStyle(
                          color: Colors.green,
                          fontSize: MediaQuery.of(context).size.width * 0.033,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Container(
              color: Colors.grey.shade300,
              height: 1,
            ),
          ],
        ),
      ),
    );
  }

}
