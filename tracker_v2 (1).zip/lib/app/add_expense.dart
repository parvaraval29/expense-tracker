import 'dart:io';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tracker/common_widgets/date_time_picker.dart';
import 'package:tracker/common_widgets/form_submit_button.dart';
import 'package:tracker/common_widgets/show_exception_alert_dialog.dart';
import 'package:tracker/services/app_user_info.dart';
import 'package:tracker/services/firestore_service.dart';
import 'models/Expense.dart';
import 'models/User.dart';

class AddExpense extends StatefulWidget {
  @override
  _AddExpenseState createState() => _AddExpenseState();
}

class _AddExpenseState extends State<AddExpense> {
  DateTime _expenseDate;
  CategoryType _type = CategoryType.travel;
  final TextEditingController _labelController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();

  bool isLoading = false;

  File _imageFile;
  final picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    final start = DateTime.now();
    _expenseDate = DateTime(start.year, start.month, start.day);
  }

  @override
  void dispose() {
    _labelController.dispose();
    _amountController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    setState(() {
      isLoading = true;
    });
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    String _url = await FirebaseService().uploadImage(_imageFile);
    User _user = AppUserInfo.getUserDetails();

    Expense expense = Expense(
      uid: id,
      date: _expenseDate,
      category: getSelectedCategory(),
      label: _labelController.text.toString(),
      amount: double.parse(_amountController.text),
      description: _descriptionController.text.toString(),
      imageUrl: _url,
      userName: _user.name,
      userId: _user.uid,
      createdDateTime: DateTime.now(),
      status: 'not-approved',
    );

    try {
      await FirebaseService().addExpense(expense);
      await FirebaseService().addUnclaimed(expense.userId, expense.amount);
     final l = await FirebaseService().getCurrentUser(expense.userId);
     AppUserInfo.setUserDetails(l);
      setState(() {
        isLoading = false;
      });
      Navigator.pop(context);
    } on FirebaseException catch (e) {
      showExceptionAlertDialog(
        context,
        title: 'Failed to add expense',
        exception: e,
      );
      setState(() {
        isLoading = false;
      });
    }
  }

  String getSelectedCategory() {
    String s = '';
    switch (_type) {
      case CategoryType.travel:
        {
          s = 'Travel';
          break;
        }
      case CategoryType.food_drink:
        {
          s = 'Food and Drink';
          break;
        }
      case CategoryType.accomodation:
        {
          s = 'Accomodation';
          break;
        }
      case CategoryType.other:
        {
          s = 'Other';
          break;
        }
    }
    return s;
  }

  Future<void> selectImage() async {
    final image = await picker.getImage(source: ImageSource.camera, imageQuality: 100);
    setState(() {
      _imageFile = File(image.path);
    });
  }

  bool get canSubmit {
    if (_labelController.text.toString() != '' && _amountController.text.toString() != '' && _imageFile != null) {
      return true;
    } else {
      return false;
    }
  }

  List<Widget> _buildChildren() {
    return [
      SizedBox(
        height: MediaQuery.of(context).size.height * 0.008,
      ),
      _buildExpenseDate(),
      SizedBox(
        height: MediaQuery.of(context).size.height * 0.01,
      ),
      _buildCategorySelector(),
      SizedBox(
        height: MediaQuery.of(context).size.height * 0.01,
      ),
      _buildLabelField(),
      SizedBox(
        height: MediaQuery.of(context).size.height * 0.01,
      ),
      _buildAmountField(),
      SizedBox(
        height: MediaQuery.of(context).size.height * 0.01,
      ),
      _buildDescriptionField(),
      SizedBox(
        height: MediaQuery.of(context).size.height * 0.01,
      ),
      _buildImageWidget(),
      SizedBox(
        height: MediaQuery.of(context).size.height * 0.01,
      ),
      isLoading ? Center(
                  child: CircularProgressIndicator(),
                )
              : FormSubmitButton(
                  text: 'Submit',
                  onPressed: () => canSubmit
                      ? submit() : (){},
                  borderRadius: MediaQuery.of(context).size.width * 0.02,
                )
    ];
  }

  Widget _buildExpenseDate() {
    return DateTimePicker(
      labelText: 'Date of Expense',
      selectedDate: _expenseDate,
      onSelectedDate: (date) => setState(() => _expenseDate = date),
    );
  }

  Widget _buildCategorySelector() {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: Text(
            'Category',
            style: TextStyle(color: Colors.grey.shade700, fontWeight: FontWeight.normal),
          ),
        ),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.008,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Row(
              children: [
                Radio(
                  value: CategoryType.travel,
                  groupValue: _type,
                  onChanged: (value) {
                    setState(() {
                      _type = value;
                    });
                  },
                ),
                Text(
                  'Travel',
                  style: new TextStyle(
                    fontSize: MediaQuery.of(context).size.width * 0.04,
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Radio(
                  value: CategoryType.food_drink,
                  groupValue: _type,
                  onChanged: (value) {
                    setState(() {
                      _type = value;
                    });
                  },
                ),
                Text(
                  'Food And Drink',
                  style: new TextStyle(fontSize: MediaQuery.of(context).size.width * 0.04),
                ),
              ],
            ),
          ],
        ),
        SizedBox(
          height: MediaQuery.of(context).size.height * 0.008,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Row(
              children: [
                Radio(
                  value: CategoryType.accomodation,
                  groupValue: _type,
                  onChanged: (value) {
                    setState(() {
                      _type = value;
                    });
                  },
                ),
                Text(
                  'Accomodation',
                  style: new TextStyle(
                    fontSize: MediaQuery.of(context).size.width * 0.04,
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Radio(
                  value: CategoryType.other,
                  groupValue: _type,
                  onChanged: (value) {
                    setState(() {
                      _type = value;
                    });
                  },
                ),
                Text(
                  'Other',
                  style: new TextStyle(fontSize: MediaQuery.of(context).size.width * 0.04),
                ),
              ],
            ),
          ],
        ),
      ],
    );
  }

  TextField _buildLabelField() {
    return TextField(
      controller: _labelController,
      decoration: InputDecoration(
        labelText: 'Label',
        hintText: 'hostel, travel',
      ),
      autocorrect: false,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.next,
    );
  }

  TextField _buildAmountField() {
    return TextField(
      controller: _amountController,
      decoration: InputDecoration(
        labelText: 'Amount',
        hintText: '100.00 GBP',
      ),
      autocorrect: false,
      keyboardType: TextInputType.number,
      textInputAction: TextInputAction.next,
    );
  }

  TextField _buildDescriptionField() {
    return TextField(
      controller: _descriptionController,
      decoration: InputDecoration(
        labelText: 'Description (Optional)',
        hintText: 'This is of travel with family.',
      ),
      autocorrect: false,
      keyboardType: TextInputType.text,
      textInputAction: TextInputAction.next,
    );
  }

  Widget _buildImageWidget() {
    return InkWell(
      onTap: () => selectImage(),
      child: Container(
        height: MediaQuery.of(context).size.height * 0.15,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border.all(
            color: Colors.black26,
            style: BorderStyle.solid,
          ),
          borderRadius: BorderRadius.all(Radius.circular(MediaQuery.of(context).size.width * 0.02)),
        ),
        child: _imageFile == null ? InkWell(child: Text('Add image')) : Image.file(_imageFile),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Expense'),
      ),
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.04),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: _buildChildren(),
          ),
        ),
      ),
    );
  }
}
