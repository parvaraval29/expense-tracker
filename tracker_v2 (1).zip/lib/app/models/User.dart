
class User {
  User({
    this.uid,
    this.name,
    this.profileUrl,
    this.isManager,
    this.claimed,
    this.unClaimed,
  });
  final String uid;
  final String name;
  final String profileUrl;
  final bool isManager;
  final double claimed;
  final double unClaimed;

  factory User.fromMap(Map<String, dynamic> data) {
    if (data == null) {
      return null;
    }
    return User(
      uid: data['uid'],
      name: data['name'],
      profileUrl: data['profileUrl'],
      claimed: double.parse(data['claimed'].toString()),
      unClaimed: double.parse(data['unClaimed'].toString()),
      isManager: data['isManager'],
    );
  }

  Map<String, dynamic> toMap(String uid) {
    return {
      'uid': uid,
      'name': name,
      'profileUrl': profileUrl,
      'claimed': claimed,
      'unClaimed': unClaimed,
      'isManager': isManager,
    };
  }
}
