enum CategoryType {travel, food_drink, accomodation, other}

  class Expense {
  Expense({
    this.uid,
    this.date,
    this.category,
    this.label,
    this.amount,
    this.description,
    this.imageUrl,
    this.userName,
    this.userId,
    this.createdDateTime,
    this.status,
  });
  final String uid;
  final DateTime date;
  final String category;
  final String label;
  final double amount;
  final String description;
  final String imageUrl;
  final String userName;
  final String userId;
  final DateTime createdDateTime;
  final String status;

  factory Expense.fromMap(Map<String, dynamic> data) {
    if (data == null) {
      return null;
    }
    return Expense(
      uid: data['uid'],
      userId: data['userId'],
      date: DateTime.fromMillisecondsSinceEpoch(data['date']),
      createdDateTime: DateTime.fromMillisecondsSinceEpoch(data['createdDateTime']),
      category: data['category'],
      label: data['label'],
      amount: double.parse(data['amount']),
      description: data['description'],
      imageUrl: data['imageUrl'],
      userName: data['userName'],
      status: data['status'],
    );
  }

  Map<String, dynamic> toMap() {
    return {
      "date": date.millisecondsSinceEpoch,
      "createdDateTime": createdDateTime.millisecondsSinceEpoch,
      "category": category,
      "label": label,
      "amount": amount.toString(),
      "description": description ?? '',
      "imageUrl": imageUrl,
      "userName": userName,
      "userId": userId,
      "status": status,
      "uid": uid,
    };
  }
}
