import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:tracker/app/home_page.dart';
import 'package:tracker/app/home_page_manager.dart';
import 'package:tracker/common_widgets/form_submit_button.dart';
import 'package:tracker/common_widgets/show_exception_alert_dialog.dart';
import 'package:tracker/services/app_user_info.dart';
import 'package:tracker/services/firestore_service.dart';


class SignInPage extends StatefulWidget {
  @override
  _SignInPageState createState() => _SignInPageState();
}

class _SignInPageState extends State<SignInPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final String invalidEmailErrorText = 'Email can\'t be empty';
  final String invalidPasswordErrorText = 'Password can\'t be empty';
  bool isLoading = false;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    setState(() {
      isLoading = true;
    });
    try {
     UserCredential userCredential = await FirebaseAuth.instance.signInWithCredential(
        EmailAuthProvider.credential(
          email: _emailController.text.toString(),
          password: _passwordController.text.toString(),
        ),
      );
     final user = userCredential.user;
     if (user != null) {
       final _user =  await FirebaseService().getCurrentUser(user.uid);
       AppUserInfo.setUserDetails(_user);
       Navigator.pushReplacement(
         context,
         MaterialPageRoute(
           builder: (context) => _user.isManager ? ManagerHomePage(user: user) : HomePage(user: user,),
         ),
       );
     }
     setState(() {
       isLoading = false;
     });
    } on FirebaseAuthException catch (e) {
      showExceptionAlertDialog(
        context,
        title: 'Sign In failed',
        exception: e,
      );
      setState(() {
        isLoading = false;
      });
    }
  }

  bool canSubmit() {
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      return false;
    } else {
      return true;
    }
  }

  List<Widget> _buildChildren() {
    return [
      _signInText(),
      SizedBox(
        height: MediaQuery.of(context).size.width * 0.3,
      ),
      _buildEmailTextField(),
      SizedBox(
        height: MediaQuery.of(context).size.width * 0.03,
      ),
      _buildPasswordTextField(),
      SizedBox(
        height: MediaQuery.of(context).size.width * 0.2,
      ),
      !isLoading ? FormSubmitButton(
        text: 'Sign in',
        onPressed: () =>  submit(),
        borderRadius: 12,
      ) : Center(child: CircularProgressIndicator()),
    ];
  }

  TextField _buildPasswordTextField() {
    return TextField(
      controller: _passwordController,
      decoration: InputDecoration(
        labelText: 'Password',
      ),
      obscureText: true,
      textInputAction: TextInputAction.done,
    );
  }

  TextField _buildEmailTextField() {
    return TextField(
      controller: _emailController,
      decoration: InputDecoration(
        labelText: 'Email',
        hintText: 'john@example.com',
      ),
      autocorrect: false,
      keyboardType: TextInputType.emailAddress,
      textInputAction: TextInputAction.next,
    );
  }

  Text _signInText() {
    return Text(
      'Sign In',
      textAlign: TextAlign.center,
      style: TextStyle(
        color: Colors.green,
        fontSize: MediaQuery.of(context).size.width * 0.06,
        fontWeight: FontWeight.bold,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Padding(
        padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.04),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: _buildChildren(),
        ),
      ),
    );
  }
}
