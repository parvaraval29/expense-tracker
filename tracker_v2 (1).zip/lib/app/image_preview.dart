import 'package:flutter/material.dart';

class ImagePreview extends StatefulWidget {
  final String url;
  ImagePreview({this.url});
  @override
  _ImagePreviewState createState() => _ImagePreviewState();
}

class _ImagePreviewState extends State<ImagePreview> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('Image Preview'),
      ),
      body: Image.network(
        widget.url,
        fit: BoxFit.cover,
      ),
    );
  }
}
