import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:tracker/app/home_page.dart';
import 'package:tracker/app/home_page_manager.dart';
import 'package:tracker/app/sign_in_page.dart';
import 'package:tracker/services/app_user_info.dart';
import 'package:tracker/services/firestore_service.dart';

class SplashPage extends StatefulWidget {
  @override
  _SplashPageState createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  User user;

  @override
  void initState() {
    super.initState();
    getUser();
  }

  getUser() async {
    user = FirebaseAuth.instance.currentUser;
    if (user != null) {
       final _user =  await FirebaseService().getCurrentUser(user.uid);
       AppUserInfo.setUserDetails(_user);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => _user.isManager ? ManagerHomePage(user: user) : HomePage(user: user,),
          ),
        );
    } else {
      Timer(Duration(seconds: 2), () {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (context) => SignInPage(),
          ),
        );
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(),
            Text(
              'Expense Tracker',
              style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width * 0.06,
                  color: Colors.black,
                  fontWeight: FontWeight.w600
              ),
            ),
            Container(),
            CircularProgressIndicator(),
            Container(),
          ],
        ));
  }
}
