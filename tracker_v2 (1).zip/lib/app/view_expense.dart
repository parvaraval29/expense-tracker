import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:tracker/app/image_preview.dart';
import 'package:tracker/app/models/Expense.dart';

class ViewExpense extends StatefulWidget {
  final Expense expense;
  ViewExpense({this.expense});
  @override
  _ViewExpenseState createState() => _ViewExpenseState();
}

class _ViewExpenseState extends State<ViewExpense> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Expense Details'),
      ),
      backgroundColor: Colors.white,
      body: _buildContent(),
    );
  }

  _buildContent() {
    return Column(
      children: [
        _image(),
        _dateAndLabel(),
        _category(),
        _description(),
      ],
    );
  }

  _image() {
    return InkWell(
      onTap: (){
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ImagePreview(url: widget.expense.imageUrl,),
          ),
        );
      },
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 0.30,
        child: Image.network(
          widget.expense.imageUrl,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  _dateAndLabel() {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.height * 0.02),
              height: MediaQuery.of(context).size.height * 0.08,
              alignment: Alignment.centerLeft,
              child: Text(
                'Date : ${DateFormat('dd/MM/yyyy').format(widget.expense.date)}',
                style: TextStyle(fontWeight: FontWeight.bold,
                fontSize: MediaQuery.of(context).size.width * 0.04),
              ),
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              height: MediaQuery.of(context).size.height * 0.08,
              alignment: Alignment.centerLeft,
              child: Text(
                'Label : ${widget.expense.label}',
                style: TextStyle(fontWeight: FontWeight.bold,
                    fontSize: MediaQuery.of(context).size.width * 0.04),
              ),
            ),
          ],
        ),
        Divider(
          color: Colors.grey,
          height: 2,
        ),
      ],
    );
  }

  _category() {
    return Column(
      children: [
        Container(
          padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.height * 0.02),
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height * 0.08,
          alignment: Alignment.centerLeft,
          child: Text(
            'Category : ${widget.expense.category}',
            style: TextStyle(fontWeight: FontWeight.bold,
                fontSize: MediaQuery.of(context).size.width * 0.04),
          ),
        ),
        Divider(
          color: Colors.grey,
          height: 2,
        ),
      ],
    );
  }

  _description() {
    if (widget.expense.description.toString() != '') {
      return Column(
        children: [
          Container(
            padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.height * 0.02),
            width: MediaQuery
                .of(context)
                .size
                .width,
            height: MediaQuery.of(context).size.height * 0.08,
            alignment: Alignment.centerLeft,
            child: Text(
              'Description : ${widget.expense.description}',
              style: TextStyle(fontWeight: FontWeight.bold,
                  fontSize: MediaQuery.of(context).size.width * 0.04),
            ),
          ),
          Divider(
            color: Colors.grey,
            height: 2,
          ),
        ],
      );
    }else{
      return Container();
    }
  }
}
