import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as FUser;
import 'package:flutter/material.dart';
import 'package:tracker/app/manger_user_view.dart';
import 'package:tracker/app/sign_in_page.dart';
import 'package:tracker/services/firestore_service.dart';
import 'package:tracker/app/models/User.dart' as u;

class ManagerHomePage extends StatefulWidget {
  final FUser.User user;
  ManagerHomePage({this.user});
  @override
  _ManagerHomePageState createState() => _ManagerHomePageState();
}

class _ManagerHomePageState extends State<ManagerHomePage> {
  bool isLoading = true;
  double totalExpense = 0;
  Map<String, u.User> allUsersData = {};
  List allUsers = [];

  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    allUsersData = await FirebaseService().getAllUsers();
    getTotalExpenses();
  }

  getTotalExpenses() async {
    totalExpense = 0;
    allUsersData.forEach((key, value) {
      totalExpense = value.claimed + totalExpense;
      allUsers.add(key);
    });
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Expenses'),
        actions: [
          Padding(
            padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.02),
            child: Center(
              child: Text('£ $totalExpense'),
            ),
          ),
          InkWell(
            onTap: () => _signOut(),
            child: Padding(
              padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.02),
              child: Center(
                child: Icon(Icons.logout),
              ),
            ),
          ),
        ],
      ),
      backgroundColor: Colors.white,
      body: isLoading
          ? Container(
              child: Center(
              child: CircularProgressIndicator(),
            ))
          : ListView.builder(
              itemCount: allUsers.length,
              itemBuilder: (context, index) {
                return userObject(allUsers[index]);
              },
            ),
    );
  }

  Widget userObject(uid) {
    return InkWell(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ManagerUserHomePage(
              user: allUsersData[uid],
            ),
          ),
        ).then((value){
          setState(() {
            isLoading = true;
            allUsersData = {};
           allUsers = [];
          });
          getData();
        });
      },
      child: Column(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.height * 0.015,
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.fromLTRB(MediaQuery.of(context).size.height * 0.01, MediaQuery.of(context).size.height * 0.008, MediaQuery.of(context).size.height * 0.01, MediaQuery.of(context).size.height * 0.008),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
               Row(
                 children: [
                   CircleAvatar(
                     backgroundColor: Colors.white,
                     radius: MediaQuery.of(context).size.width * 0.04,
                     child: Image.network(allUsersData[uid].profileUrl),
                   ),
                   SizedBox(
                     width: MediaQuery.of(context).size.width * 0.02,
                   ),
                   Text(
                     '${allUsersData[uid].name}',
                     style: TextStyle(fontWeight: FontWeight.bold, fontSize: MediaQuery.of(context).size.width * 0.04, color: Colors.black),
                   ),
                 ],
               ),
                Column(
                  children: [
                    Text(
                      allUsersData[uid].unClaimed == null ? 'unclaimed expenses : 0.0' : 'unclaimed expenses : ${allUsersData[uid].unClaimed}',
                      style: TextStyle(fontWeight: FontWeight.normal, fontSize: MediaQuery.of(context).size.width * 0.033, color: Colors.black54),
                    ),
                  ],
                )
              ],
            ),
          ),
          Container(
            color: Colors.grey.shade300,
            height: 1,
          ),
        ],
      ),
    );
  }

  _signOut() async {
    await FUser.FirebaseAuth.instance.signOut();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => SignInPage(),
      ),
    );
  }
}
