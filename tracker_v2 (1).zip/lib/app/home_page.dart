import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart' as FUser;
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:tracker/app/add_expense.dart';
import 'package:tracker/app/models/Expense.dart';
import 'package:tracker/app/models/User.dart';
import 'package:tracker/app/sign_in_page.dart';
import 'package:tracker/app/view_expense.dart';
import 'package:tracker/common_widgets/form_submit_button.dart';
import 'package:tracker/services/app_user_info.dart';
import 'package:tracker/services/firestore_service.dart';
import 'package:tracker/app/models/User.dart' as u;

class HomePage extends StatefulWidget {
  final FUser.User user;
  HomePage({this.user});
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  u.User _user = AppUserInfo.getUserDetails();

  refreshUserData(){
    setState(() {
      _user = AppUserInfo.getUserDetails();
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
            appBar: AppBar(
              title: Text('Expenses'),
              actions: [
                Padding(
                  padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.02),
                  child: Center(
                    child: Text('£ ${_user.unClaimed.toString()}'),
                  ),
                ),
                InkWell(
                  onTap: () => _signOut(),
                  child: Padding(
                    padding: EdgeInsets.all(MediaQuery.of(context).size.width * 0.02),
                    child: Center(
                      child: Icon(Icons.logout),
                    ),
                  ),
                ),
              ],
            ),
            backgroundColor: Colors.white,
            body: StreamBuilder(
                stream: FirebaseFirestore.instance.collection('expenses').where('userId', isEqualTo: _user.uid).where('status', isEqualTo: 'not-approved').snapshots(),
                builder: (context, snapshot) {
                  return !snapshot.hasData
                      ? CircularProgressIndicator()
                      : ListView.builder(
                          itemCount: snapshot.data.docs.length,
                          itemBuilder: (context, index) {
                            return expenseObject(snapshot.data.docs[index]);
                          },
                        );
                }),
            floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
            floatingActionButton: FormSubmitButton(
              text: 'Add expenses',
              borderRadius: MediaQuery.of(context).size.width * 0.05,
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute<void>(
                  fullscreenDialog: true,
                  builder: (context) => AddExpense(),
                )).then((value){
                  refreshUserData();
                });
              },
            ),
          );
  }

  Widget expenseObject(doc) {
    Expense expense = Expense.fromMap(doc.data());
    return InkWell(
      onTap: (){
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ViewExpense(expense: expense,),
          ),
        );
      },
      child: Column(
        children: [
          SizedBox(
            height: MediaQuery.of(context).size.width * 0.008,
          ),
          Container(
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.fromLTRB(MediaQuery.of(context).size.height * 0.01, MediaQuery.of(context).size.height * 0.008, MediaQuery.of(context).size.height * 0.01, MediaQuery.of(context).size.height * 0.008),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  DateFormat('dd/MM/yyyy').format(expense.date),
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: MediaQuery.of(context).size.width * 0.04, color: Colors.black),
                ),
                SizedBox(
                  height: 5,
                ),
                Text(
                  'Added on  : ${DateFormat('dd/MM/yyyy').format(expense.createdDateTime)}',
                  style: TextStyle(fontWeight: FontWeight.normal, fontSize: MediaQuery.of(context).size.width * 0.03, color: Colors.black54),
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.width * 0.02,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      expense.label,
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: MediaQuery.of(context).size.width * 0.035,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      '£ ${expense.amount}',
                      style: TextStyle(
                        color: Colors.green,
                        fontSize: MediaQuery.of(context).size.width * 0.035,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Container(
            color: Colors.grey.shade300,
            height: 1,
          ),
        ],
      ),
    );
  }

  _signOut() async {
    await FUser.FirebaseAuth.instance.signOut();
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => SignInPage(),
      ),
    );
  }
}
