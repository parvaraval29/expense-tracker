import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:tracker/app/models/Expense.dart';
import 'package:tracker/app/models/User.dart';
import 'package:path/path.dart' as Path;

class FirebaseService {
  final _firebaseInstance = FirebaseFirestore.instance;

  Future<User> getCurrentUser(String uid) async {
    final doc = await _firebaseInstance.collection('users').doc(uid).get();
    if (doc.exists) {
      return User.fromMap(doc.data());
    }
  }

  Future<void> addExpense(Expense expense) async {
    await _firebaseInstance.collection('expenses').doc(expense.uid).set(expense.toMap());
  }

  Future<void> approveExpense(Expense expense) async {
    await _firebaseInstance.collection('expenses').doc(expense.uid).update({'status' : 'approved'});
  }

  Future<void> addUnclaimed(String uid, double amt) async {
    await _firebaseInstance.collection('users').doc(uid).update({'unClaimed' : FieldValue.increment(amt)});
  }

  Future<void> addClaimed(String uid, double unclaimedAmt, double claimedAmt) async {
    await _firebaseInstance.collection('users').doc(uid).update({'unClaimed' : FieldValue.increment(unclaimedAmt), 'claimed' : FieldValue.increment(claimedAmt)});
  }

  Future<Map<String, User>> getAllUsers() async {
    Map<String, User> users = {};
    final doc = await _firebaseInstance.collection('users').where('isManager', isEqualTo: false).get();
    doc.docs.forEach((element) {
      users[element.id] = User.fromMap(element.data());
    });
    return users;
  }

  Future<String> uploadImage(File file) async {
    if (file != null) {
      print("file path:-> ${file.path}");
      var imgPathAndName = 'images/${DateTime.now().microsecondsSinceEpoch.toString()}${Path.extension(file.path)}';
      print('name is -> $imgPathAndName');

      Reference storageReference = FirebaseStorage.instance.ref();
      await storageReference.child(imgPathAndName).putFile(file);

      String downloadUrl = await storageReference.child(imgPathAndName).getDownloadURL();
      return downloadUrl;
    }
  }
}
