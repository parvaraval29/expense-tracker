
import 'package:tracker/app/models/User.dart';

class AppUserInfo{
  static User _userDetails;

  static setUserDetails(user) => _userDetails = user;

  static getUserDetails() => _userDetails;
}